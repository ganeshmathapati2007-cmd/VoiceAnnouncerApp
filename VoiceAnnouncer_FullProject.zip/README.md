# Voice Notification Announcer App & Website Package

This package contains everything you requested:
1. **Official Website (`website/index.html`)**: A sleek, dark-themed responsive website featuring the app description, download link, and setup guide.
2. **Android App Source Code (`app/`)**: A complete Java/Android Studio project that listens to notifications from WhatsApp, YouTube, SMS, etc., and reads the sender's name out loud using Text-to-Speech (TTS).

## How to use:
- **To view the Website**: Double-click and open `website/index.html` in any web browser (Chrome, Edge, Safari).
- **To build the APK**: Open the `app/` folder in Android Studio and click on `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
- Put the compiled `.apk` file inside the `website/` folder with the name `VoiceAnnouncer_v1.0.apk` so the website's download link works seamlessly!
