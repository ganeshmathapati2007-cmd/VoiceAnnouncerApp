package com.example.voiceannouncer;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Switch switchService;
    private Button btnPermission;
    private TextView txtStatus;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchService = findViewById(R.id.switchService);
        btnPermission = findViewById(R.id.btnPermission);
        txtStatus = findViewById(R.id.txtStatus);
        prefs = getSharedPreferences("VoiceAppPrefs", MODE_PRIVATE);

        // Load saved state
        boolean isEnabled = prefs.getBoolean("service_active", false);
        switchService.setChecked(isEnabled);
        updateStatusText();

        // Permission Button Click
        btnPermission.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            startActivity(intent);
        });

        // Switch Toggle Event
        switchService.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !isNotificationServiceEnabled()) {
                Toast.makeText(this, "Pehle Notification Permission enable karein!", Toast.LENGTH_LONG).show();
                switchService.setChecked(false);
                return;
            }
            prefs.edit().putBoolean("service_active", isChecked).apply();
            updateStatusText();
            String msg = isChecked ? "Voice Announcer Active Ho Gaya!" : "Service Band Kar Di Gayi Hai";
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatusText();
    }

    private void updateStatusText() {
        if (!isNotificationServiceEnabled()) {
            txtStatus.setText("Status: Permission Required ❌");
            txtStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            btnPermission.setEnabled(true);
        } else if (switchService.isChecked()) {
            txtStatus.setText("Status: Running & Listening 🔊");
            txtStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            btnPermission.setEnabled(false);
        } else {
            txtStatus.setText("Status: Service Stopped ⏸️");
            txtStatus.setTextColor(getResources().getColor(android.R.color.darker_gray));
        }
    }

    private boolean isNotificationServiceEnabled() {
        String pkgName = getPackageName();
        final String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (String name : names) {
                final ComponentName cn = ComponentName.unflattenFromString(name);
                if (cn != null && TextUtils.equals(pkgName, cn.getPackageName())) {
                    return true;
                }
            }
        }
        return false;
    }
}