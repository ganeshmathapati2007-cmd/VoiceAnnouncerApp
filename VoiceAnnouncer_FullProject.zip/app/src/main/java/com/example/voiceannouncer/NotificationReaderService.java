package com.example.voiceannouncer;

import android.app.Notification;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import java.util.Locale;

public class NotificationReaderService extends NotificationListenerService implements TextToSpeech.OnInitListener {

    private TextToSpeech tts;
    private SharedPreferences prefs;
    private boolean isTtsReady = false;

    @Override
    public void onCreate() {
        super.onCreate();
        tts = new TextToSpeech(this, this);
        prefs = getSharedPreferences("VoiceAppPrefs", MODE_PRIVATE);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(new Locale("hi", "IN")); // Hindi/Indian English support
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US);
            }
            isTtsReady = true;
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!isTtsReady) return;

        // Check if service is toggled ON by user
        boolean isActive = prefs.getBoolean("service_active", false);
        if (!isActive) return;

        String packageName = sbn.getPackageName();
        Notification notification = sbn.getNotification();
        if (notification == null) return;

        Bundle extras = notification.extras;
        String title = extras.getString(Notification.EXTRA_TITLE); // Sender Name
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT); // Message Body

        if (title == null || title.trim().isEmpty()) return;

        // Identify App Name
        String appName = "app";
        if (packageName.contains("whatsapp")) {
            appName = "WhatsApp";
        } else if (packageName.contains("youtube")) {
            appName = "YouTube";
        } else if (packageName.contains("messaging") || packageName.contains("sms")) {
            appName = "Message";
        } else if (packageName.contains("instagram")) {
            appName = "Instagram";
        } else if (packageName.contains("telegram")) {
            appName = "Telegram";
        } else {
            // Ignore background system notifications if not from popular communication apps
            return;
        }

        // Create Announcement Speech
        String speechText = "Message by " + appName + ", sender " + title;
        Log.d("VoiceAnnouncer", "Speaking: " + speechText);

        // Speak out the notification
        tts.speak(speechText, TextToSpeech.QUEUE_ADD, null, null);
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}